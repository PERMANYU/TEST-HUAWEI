export default {
    bNav:true,
    bFoot:false,
    bLoading:false,
    homeData:[],
    followData:[],
    buyCar:[],
    list:[],
    userData:{a:1}
  };
  