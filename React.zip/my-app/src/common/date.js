import {fillzero} from "./fillzero";

export const date=time=>'时间';